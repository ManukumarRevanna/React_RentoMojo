import React, { Component } from 'react'

export default class PostDetails extends Component {
    render() {
        return (
            <div>
                Post Details
            </div>
        )
    }
}
