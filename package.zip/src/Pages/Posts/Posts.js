import React, { Component } from 'react'

export default class Posts extends Component {
    render() {
        return (
            <div>
                Posts
            </div>
        )
    }
}
