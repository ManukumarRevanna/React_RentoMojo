import React, { Component } from 'react'
import { BrowserRouter, Route, Switch} from 'react-router-dom';

import RoutesConfig from './RoutesConfig'

export default class Routes extends Component {
    componentDidMount() {
        
    }
    render() {
        return (
            <div>
                <BrowserRouter>
                    <Switch>
                        {RoutesConfig.map(route => {
                        return <Route {...route} key={route.path} />

                    })
                }
                    </Switch>
                    
                </BrowserRouter>
            </div>
        )
    }
}
