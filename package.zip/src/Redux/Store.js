import { createStore, applyMiddleware } from 'redux';
import Thunk from 'redux-thunk';
import Logger from 'redux-logger';
import { composeWithDevTools } from 'redux-devtools-extension';

const Store = createStore(, composeWithDevTools(applyMiddleware(Thunk, Logger)));

export default Store;