const initialData = {};

export const HomeReducer = (state=initialData, action) => {
    switch (action.type) {
        case ''
    }
}